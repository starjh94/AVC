<?session_start();
?>
<?php
$now_userid =$_SESSION['user_id'];
$conn = mysqli_connect("localhost","root","apmsetup","board"); // 데이터베이스 연결
if (mysqli_connect_errno()) {
	echo "MySQL 연결 실패 : " . mysqli_connect_error();
	}

$b = $_GET['b'];

		$sql1 = 'SELECT * FROM ';
	 $sql2 =' WHERE b_no= ';
	$sql3 = $sql1 . $now_userid . $sql2 . $b;
$sql4 = 'SELECT * FROM jkjk54 WHERE b_no = 1 ';
	$result = mysqli_query($conn,$sql3); //select 구문을 이용해 칼럽값을 가져옴
	
	$row = $result->fetch_assoc();

	// mysqli_fetch_array 함수를 사용하여 값을 가져옴
			// mysqli_fetch_array 함수는 한번에 하나씩 데이터를 읽어오며, 배열형태로 저장됩니다.

			$a = $row['data'];
			echo $a;
			$path = $row['filename'];
			$fn = 'C:/123/' . $path;
			
			$fp = fopen($fn, "wb+");
			fwrite($fp,$a);
			fclose($fp);
		 // user_name의 값(데이터를 가져올때 $row[]를 사용함
	 
     echo("<script>location.replace('./index.php');</script>"); 

	
mysqli_close($conn);
?>