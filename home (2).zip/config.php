
<?php
$DB['host'] = 'localhost';
$DB['db'] = 'board';
$DB['id'] = 'root';
$DB['pw'] = 'apmsetup';
?> 