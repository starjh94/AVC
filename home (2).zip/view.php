<?
session_start();
?>
<?php
$b = $_GET['b'];
	$now_userid =$_SESSION['user_id'];
	$db = new mysqli('localhost', 'root', 'apmsetup', 'board');

	if($db->connect_error) {
		die('데이터베이스 연결에 문제가 있습니다.\n관리자에게 문의 바랍니다.');
	}
	
	$bbb = $bNo;
	if(!empty($bNo) && empty($_COOKIE['images_' . $bNo])) {
		$sql = 'update images set b_hit = b_hit + 1 where b_no = ' . $bNo;
		$result = $db->query($sql); 
		if(empty($result)) {
			?>
			<script>
				alert('오류가 발생했습니다.');
				history.back();
			</script>
			<?php 
		} else {
			setcookie('backupdata' . $bNo, TRUE, time() + (60 * 60 * 24), '/');
		}
	}
	$sql1 = 'SELECT * FROM ';
	 $sql2 =' WHERE b_no= ';
	$sql3 = $sql1 . $now_userid . $sql2 . $b;
$sql4 = 'SELECT * FROM jkjk54'; //WHERE b_no = 1 ';
	$result = $db->query($sql3);
	$row = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	
	<link rel="stylesheet" href="./css/normalize.css" />
	<link rel="stylesheet" href="./css/board.css" />5
</head>
<body>
	<article class="boardArticle">
		<h3>파일</h3>
		<div id="boardView">			
			<div id="boardInfo">
				<span id="boardID">게시자: <?php  echo $row['up_user']?></span>
				<span id="boardDate">작성일: <?php echo $row['up_time']?></span>
				<br>파일명를 누르시면 <?php echo "C:\Users\user\Downloads"?> 에 파일이 저장됩니다.<br>
			</div>
			<a href="./file down.php?b=<?php echo $b?>"><?php echo $row['filename']?></a>
			<div class="btnSet">
				<a href="./delete.php?bno=<?php echo $bNo?>">삭제</a>
				<a href="./">목록</a>
			</div>
		</div>
	</article>
</body>
</html>