<?session_start();
?>
<html>
    <head>
    
        <title>로그인 완료 페이지</title>
        <meta charset="utf-8" >
    </head>
    <body>
        로그인 완료 페이지<br />
        <hr />

    </body>
    <a href="../index.php">확인</a>
</html> 