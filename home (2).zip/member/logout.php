<?php
session_start(); //Start the current session
session_destroy(); //Destroy it! So we are logged out now
header("location:http://localhost/home/member/login.php?msg=로그아웃 되었습니다."); // Move back to login.php with a logout message
?>