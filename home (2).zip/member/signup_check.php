<?php
include_once ('../config.php');
$con =mysql_connect($DB['host'], $DB['id'], $DB['pw']);

if (mysqli_connect_error()) {
    exit('Connect Error (' . mysqli_connect_errno() . ') '. mysqli_connect_error());
}

extract($_POST);

mysql_select_db("board",$con);
$q = "INSERT INTO user_data ( user_id, user_pw) VALUES ( '$user_idd', '$user_pass')";
$qq = "use board";
$q2 ="create table ";
$q3 = $user_idd;
$q4 = "(
b_no int unsigned NOT NULL PRIMARY KEY AUTO_INCREMENT ,
filename char( 50 ) ,
up_user char( 11 ) ,
 DATA blob,
up_time DATETIME,
FOREIGN KEY ( up_user ) REFERENCES user_data( user_id ) 
)";
$q6='CREATE RIGGER ';
$q7 ='_backup_time_tiger BEFORE INSERT ON ';
$q8= 'FOR EACH ROW SET NEW.up_time= NOW()';
$q5 = $q2 . $q3 . $q4;
$q9 = $q6 . $q3 . $q7 . $q8;

mysql_query($q,$con);
mysql_query($q5,$con);

mysql_close($con);
?>
<!DOCTYPE html>
<meta charset="utf-8" >  
<html>
회원가입 완료!<br>
<a href="./login.php?bno=<?php echo $bNo?>">로그인</a>
</html>
 
