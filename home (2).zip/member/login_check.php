<?
session_start();
?>
<?php
include_once ('../config.php');
$mysqli = new mysqli($DB['host'], $DB['id'], $DB['pw'], $DB['db']);
if (mysqli_connect_error()) {
    exit('Connect Error (' . mysqli_connect_errno() . ') '. mysqli_connect_error());
}

extract($_POST); 
echo $user_pass;
$q = "SELECT * FROM user_data WHERE user_id='$user_id'";
$result = $mysqli->query( $q);
if($result->num_rows==1) {
    //해당 ID 의 회원이 존재할 경우
    // 암호가 맞는지를 확인
    
    $row = $result->fetch_array(MYSQLI_ASSOC);
    if( $row['user_pw'] == $user_pass ) {
        // 올바른 정보
        $_SESSION['is_logged'] = 'YES';
		$_SESSION['user_id'] = $user_id;
		echo("<script>location.replace('http://localhost/home/index.php');</script>");
    }
    else {
        // 암호가 틀렸음
        echo 'wrong password';
        $_SESSION['is_logged'] = 'NO';
        $_SESSION['user_id'] = '';
        
    }

}
else {
   echo "not found";
    
}
?>